"""Spotify e temperatura da CPU em um TURZX 3,5 polegadas, protocolo Rev. A."""
import argparse
import asyncio
import io
import math
import os
import struct
from pathlib import Path
from functools import lru_cache

from PIL import Image, ImageDraw, ImageFont, ImageOps

WIDTH, HEIGHT = 320, 480
BACKGROUND = "#111922"


@lru_cache(maxsize=8)
def font(size):
    path = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "segoeui.ttf"
    for face in (str(path), "DejaVuSans.ttf"):
        try:
            return ImageFont.truetype(face, size)
        except OSError:
            continue
    return ImageFont.load_default()


def music_panel(title, artist, cover):
    image = Image.new("RGB", (WIDTH, 390), BACKGROUND)
    draw = ImageDraw.Draw(image)
    if cover is not None:
        image.paste(ImageOps.fit(cover, (WIDTH, WIDTH), method=Image.Resampling.LANCZOS))
    else:
        draw.text((160, 160), "Spotify", font=font(40), fill="#1ed760", anchor="mm")
    for label, size, y in [(title or "Aguardando Spotify", 22, 329), (artist, 16, 360)]:
        trimmed = label
        while trimmed and draw.textlength(trimmed, font=font(size)) > WIDTH - 28:
            trimmed = trimmed[:-2].rstrip("…") + "…"
        draw.text((14, y), trimmed, font=font(size), fill="white")
    return image


def cpu_panel(value):
    image = Image.new("RGB", (WIDTH, 90), "#1d2c36")
    draw = ImageDraw.Draw(image)
    draw.text((14, 45), "CPU", font=font(24), fill="#9cdbcb", anchor="lm")
    label = "Sem leitura" if value is None else f"{value} °C"
    draw.text((306, 45), label, font=font(26 if value is None else 43), fill="white", anchor="rm")
    return image


def temperature():
    import pythoncom
    import win32com.client
    try:
        service = win32com.client.GetObject(r"winmgmts:\\.\root\LibreHardwareMonitor")
        sensors = service.ExecQuery("SELECT * FROM Sensor WHERE SensorType='Temperature'")
        values = []
        for sensor in sensors:
            parent = str(sensor.Parent).lower()
            if not parent.startswith(("/intelcpu/", "/amdcpu/")) or sensor.Value is None:
                continue
            name = sensor.Name.lower()
            priority = 0 if ("package" in name or "tctl" in name) else 1
            value = float(sensor.Value)
            if math.isfinite(value):
                values.append((priority, value))
        if values:
            best = min(p for p, _ in values)
            return round(max(v for p, v in values if p == best))
    except (pythoncom.com_error, TypeError, ValueError):
        pass
    return None


class Spotify:
    def __init__(self):
        self.key, self.cover = None, None

    async def read(self, manager):
        from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status
        from winrt.windows.storage.streams import Buffer, InputStreamOptions
        sessions = [s for s in manager.get_sessions() if "spotify" in s.source_app_user_model_id.lower()]
        if not sessions:
            self.key, self.cover = None, None
            return "", "", None
        session = next((s for s in sessions if s.get_playback_info().playback_status == Status.PLAYING), sessions[0])
        info = await session.try_get_media_properties_async()
        key = (info.title, info.artist, info.album_title, info.track_number)
        if key != self.key:
            self.key, self.cover = key, None
        if self.cover is None and info.thumbnail:
            stream = await info.thumbnail.open_read_async()
            try:
                if 0 < stream.size <= 12 * 1024 * 1024:
                    data = bytearray()
                    while len(data) < stream.size:
                        count = min(65536, stream.size - len(data))
                        block = await stream.read_async(Buffer(count), count, InputStreamOptions.NONE)
                        if not block.length:
                            break
                        data.extend(bytes(block)[:block.length])
                    with Image.open(io.BytesIO(data)) as picture:
                        self.cover = ImageOps.fit(picture.convert("RGB"), (WIDTH, WIDTH))
            except (OSError, ValueError):
                pass
            finally:
                stream.close()
        return info.title, info.artist, self.cover


def send_region(port, image, top):
    # Rev. A: quatro coordenadas inclusivas de 10 bits e comando de bitmap.
    width, height = image.size
    coords = (top << 20) | ((width - 1) << 10) | (top + height - 1)
    port.write(coords.to_bytes(5, "big") + bytes([197]))
    pixels = bytearray(2 * width * height)
    for i, (r, g, b) in enumerate(image.getdata()):
        rgb565 = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
        struct.pack_into("<H", pixels, i * 2, rgb565)
    for offset in range(0, len(pixels), 2560):
        port.write(pixels[offset:offset + 2560])


def screen():
    import serial
    from serial.tools.list_ports import comports
    ports = list(comports())
    found = [p for p in ports if p.serial_number == "USB35INCHIPSV2"
             or (p.vid, p.pid) == (0x1A86, 0x5722)]
    if len(found) != 1:
        for p in ports:
            print(p.device, p.description, p.hwid)
        raise RuntimeError("Conecte apenas um painel compatível, com cabo USB de dados. Consulte LEIA-ME.txt.")
    return serial.Serial(found[0].device, 115200, timeout=1, write_timeout=8)


async def run(preview):
    from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as Manager
    manager = await Manager.request_async()
    spotify = Spotify()
    port = None
    if preview:
        import tkinter as tk
        from PIL import ImageTk
        window = tk.Tk()
        window.title("Prévia | Spotify e CPU")
        label = tk.Label(window)
        label.pack()
        window.update()
    else:
        port = screen()
    try:
        if port:
            port.write(b"E" * 6)
            reply = port.read(6)
            if reply not in (b"", bytes([1]) * 6):
                raise RuntimeError("A resposta USB não corresponde a um painel Rev. A de 3,5 polegadas.")
            port.write(bytes(5) + bytes([109]))
            port.write(bytes(5) + bytes([121, 100]) + struct.pack(">HH", WIDTH, HEIGHT) + bytes(5))
        last_song, last_temp = object(), object()
        frame = Image.new("RGB", (WIDTH, HEIGHT))
        while True:
            try:
                title, artist, cover = await spotify.read(manager)
            except (OSError, RuntimeError):
                title, artist, cover = "Spotify indisponível", "", None
            song = (title, artist, spotify.key, id(cover))
            value = temperature()
            changed = False
            if song != last_song:
                music = music_panel(title, artist, cover)
                frame.paste(music)
                if port:
                    send_region(port, music, 0)
                last_song, changed = song, True
            if value != last_temp:
                cpu = cpu_panel(value)
                frame.paste(cpu, (0, 390))
                if port:
                    send_region(port, cpu, 390)
                last_temp, changed = value, True
            if preview:
                if changed:
                    photo = ImageTk.PhotoImage(frame)
                    label.configure(image=photo)
                try:
                    for _ in range(20):
                        window.update()
                        await asyncio.sleep(0.1)
                except tk.TclError:
                    return
            else:
                await asyncio.sleep(2)
    finally:
        if port:
            port.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--previa", action="store_true")
    try:
        asyncio.run(run(parser.parse_args().previa))
    except KeyboardInterrupt:
        pass
    except (RuntimeError, OSError) as error:
        raise SystemExit(f"Falha: {error}. Feche o TURZX e consulte LEIA-ME.txt.")
