@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3.12 -m venv .venv
  if errorlevel 1 goto :python
)
fc /b requirements.txt .venv\instalado.txt >nul 2>&1
if errorlevel 1 (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto :falha
  copy /y requirements.txt .venv\instalado.txt >nul
)
echo 1 - Mostrar na mini tela USB
echo 2 - Testar na janela de previa
choice /c 12 /n /m "Escolha 1 ou 2: "
if errorlevel 2 (
  ".venv\Scripts\python.exe" painel.py --previa
) else (
  ".venv\Scripts\python.exe" painel.py
)
if errorlevel 1 goto :falha
exit /b 0
:python
echo Instale o Python 3.12 de 64 bits com o Python Launcher. Veja LEIA-ME.txt.
:falha
pause
exit /b 1
